<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.0" name="background" tilewidth="32" tileheight="32" tilecount="1504" columns="32">
 <image source="background.png" width="1024" height="1504"/>
</tileset>
